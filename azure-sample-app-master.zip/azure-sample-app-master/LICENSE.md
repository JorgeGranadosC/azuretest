The license for Progress Sitefinity CMS is available here (https://www.progress.com/legal/license-agreements/sitefinity/license-agreement) 
The terms of the “Trial” license (set forth in the Sitefinity EULA available at: https://www.progress.com/legal/license-agreements/sitefinity/license-agreement) 
applies unless you have obtained a commercial license in which case your use of the Sitefinity Web App is subject to the same terms which
govern your use of Sitefinity.

Copyright © 2020 Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
